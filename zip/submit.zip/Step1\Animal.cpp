/**
 * \file Animal.cpp
 *
 * \author Moez Abbes
 */

#include <iostream>
#include "Animal.h"
using namespace std;

/**
 * Destructor
 */
CAnimal::~CAnimal()
{
}